#include <string>
#include <fstream>
#include <iostream>

void print(const std::string& text, std::ostream& out = std::cout);  //документируем функции print
void print(const std::string& text, std::ofstream& out);  //документируем функции print
